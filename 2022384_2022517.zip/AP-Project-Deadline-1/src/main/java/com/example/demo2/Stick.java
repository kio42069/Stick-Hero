package com.example.demo2;

public class Stick {
    private int length;

    public void increaseLength(){}
    public void fallDown(){}

    public int getLength() {
        return length;
    }

    public void setLength(int length) {
        this.length = length;
    }
}
