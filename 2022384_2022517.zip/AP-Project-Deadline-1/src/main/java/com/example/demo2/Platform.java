package com.example.demo2;

public class Platform {
    private int platformWidth;
    private int platformX;

    public void spawnPlatform(){}

    public int getPlatformWidth() {
        return platformWidth;
    }

    public void setPlatformWidth(int platformWidth) {
        this.platformWidth = platformWidth;
    }

    public int getPlatformX() {
        return platformX;
    }

    public void setPlatformX(int platformX) {
        this.platformX = platformX;
    }
}
